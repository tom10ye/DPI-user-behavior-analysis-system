package cn.fudanyang.view;

public class ChartView {

}
