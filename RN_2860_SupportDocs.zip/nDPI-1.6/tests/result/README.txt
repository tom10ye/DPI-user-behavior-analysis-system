Place here test results for pcaps used for regressions testing

Example 

for pcap/myprotocol.pcap add result/myprotocol.result
